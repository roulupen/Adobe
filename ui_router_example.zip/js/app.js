
var app = angular.module("CustomerApp",[]);

app.controller("CustomerController",function($scope){
	$scope.customers = customers;
	$scope.filteredCustomers = $scope.customers;
	
	$scope.currentCustomer = null;
	
	$scope.editMode = false;
	
	$scope.openCustomerEditor = function(customer) {
		$scope.currentCustomer = customer;
		$scope.editMode = true;
	}

	$scope.updateCustomer = function(customer) {
		/*
		 $http.put("customers", JSON.stringify(customer)).success(function(data) {});
		 */
		$scope.editMode = false;
	}
	
	$scope.deleteCustomer = function(customer) {
		/*
		 	$http.delete("customers/" + customer.id).success(function(data) {});
		 */
		$scope.customers.splice($scope.customers.indexOf(customer),1);
	}
	
	
	$scope.$on("updateView", function(event,searchText){
		console.log(searchText);
		var result = [];
		$scope.customers.forEach(function(customer) {
			if(customer.firstName.indexOf(searchText) >= 0
					||
					customer.lastName.indexOf(searchText) >= 0) {
				result.push(customer);
			}
		});
		$scope.filteredCustomers = result;
	}) ;
});


app.controller("CustomerMenuController",function($scope,$rootScope){
	$scope.searchText = "";
	
	$scope.update = function() {
		$scope.$broadcast("updateView",$scope.searchText);
	}
});

app.controller("CustomerOrderController",function($scope, $stateParams){
	$scope.orders = [];
	var id = $stateParams.id;
	var selCustomer = null;
	customers.forEach(function(customer) {
		if(customer.id == id) {
			selCustomer = customer;
		}
	});
	
	selCustomer.orders.forEach(function(order) {
		$scope.orders.push(order);
	});
});


var customers = [
                 {
                	 "id":1,"firstName":"Rajesh","lastName":"Sharma","gender":"male",
                	 orders: [
                	          {"product":"iPhone 6","price":56000.00,"quantity":1},
                	          {"product":"Reynolds Pen","price":45.66,"quantity":3}
                	          ]
                 },
                 {
                	 "id":2,"firstName":"Suresh","lastName":"Sharma","gender":"male",
                	 orders: [
                	          {"product":"Moto G","price":12990.00,"quantity":1}
                	          ]
                 },
                 {
                	 "id":3,"firstName":"Anitha","lastName":"Kumar","gender":"female",
                	 orders: [
                	          {"product":"iPhone 6","price":56000.00,"quantity":1},
                	          {"product":"Reynolds Pen","price":45.66,"quantity":3}
                	          ]
                 },
                 {
                	 "id":4,"firstName":"Karthik","lastName":"Kumar","gender":"male",
                	 orders: [
                	          {"product":"Samsung WM","price":35000.00,"quantity":1},
                	          {"product":"LG Micro Oven","price":22000.00,"quantity":1}
                	          ]
                 },
                 {
                	 "id":5,"firstName":"Sunita","lastName":"Gowda","gender":"female" 
                 }
                 ];
 