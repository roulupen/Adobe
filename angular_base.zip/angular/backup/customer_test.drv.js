/*
* Directives used for Customer Model
*/

(function(){
	var ang = angular.module("CustomerDirectiveModule",[]);
	ang.directive("cardView", function(){
		return {
			'restrict': 'EA',
			'scope' : {
				'first': '=',
				'last' : '=',
				'info' : '=',
				'img' : '=',
				'delete': '&'
			},
			'templateUrl' : 'app/partials/card_test.tmpl.html'
		}
	});

	ang.directive("listView", function(){
		return {
			'restrict': 'EA',
			'templateUrl' : 'app/partials/list.tmpl.html'
		}
	});
})();