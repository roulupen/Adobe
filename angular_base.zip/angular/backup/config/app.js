(function(){
	var mainApp = angular.module("MainModule",['ngRoute',
		'ngCookies','CustomerModule']);
	
	mainApp.config(function($routeProvider,$locationProvider){
		$routeProvider
			.when('/',{
				templateUrl: 'app/pages/home.html'
			})
			.when('/customers',{
				templateUrl: 'app/pages/customer.html',
				controller:'CustomerListController'
			})
			.otherwise({ redirectTo: '/' });
	});
	
	
})();