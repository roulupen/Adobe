describe('Customer controllers test', function() {
  var rootScope; 
  var scope;
  var menuScope;
 
  beforeEach(function(){
    module('CustomerDirectiveModule');
    module('CustomerModule');
    inject(function($rootScope,$controller){
       rootScope = $rootScope;
       scope = $rootScope.$new();
       $controller('CustomerListController',{$scope:scope});

       menuScope = $rootScope.$new();
        $controller('CustomerMenuController',{$scope:menuScope});
    });
  });

  //describe('Customer List Controller tests', function(){
    it('should create "customer" model with 6 customers', function() {
      expect(scope.customers.length).toBe(6);
    });
    
    it('should respond to the "filter_change" event', function() {
    rootScope.$broadcast("filter_change","Rao");
    console.log(scope.customers);
    expect(scope.customers.length).toBe(2);
    
     rootScope.$broadcast("filter_change","Larry");
     expect(scope.customers.length).toBe(1);
 
  });   

  //});
});