escribe('Customer controllers test', function() {
  

  beforeEach(module('CustomerModule'));
  var $controller;
  beforeEach(inject(function(_$controller_){
        $controller = _$controller_;
   }));

  describe('Customer List Controller tests', function(){
    var scope, ctrl;
    scope = {};
    ctrl = $controller('CustomerListController', {$scope:scope});
    
    it('should create "customer" model with 6 customers', function() {
      expect(scope.customers.length).toBe(6);
    });
   
  });
});