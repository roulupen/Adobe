// conf.js
exports.config = {
  framework: 'jasmine2',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['spec.js'],
  // Options to be passed to Jasmine-node.
  onPrepare: function() {     
      var jasmineReporters = require('jasmine-reporters');
jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
    consolidateAll: true,
    savePath: 'testresults',
    filePrefix: 'reportXMLoutput'
}));
 
   /* require('jasmine-reporters');
    jasmine.getEnv().addReporter(
      new jasmine.JUnitXmlReporter(null, true, true, 'report')
    );*/
  },

  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000
  },
  
  multiCapabilities: [{
	    browserName: 'chrome'
	  }]
};

//var jasmine = require('jasmine-reporters');
//jasmine.getEnv().addReporter(new jasmine.JUnitXmlReporter('outputdir/', true, true));

