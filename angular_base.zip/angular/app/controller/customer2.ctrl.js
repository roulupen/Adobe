/**
* Customer controller
*/

(function(){
	// declare a CustomerModule with NO DI [ Dependency Injection ]
	var ang = angular.module("CustomerModule",
		['CustomerDirectiveModule','CustomerServiceModule']);

	/*
		Create a CustomerMenuController function and inject $scope and $rootScope
	*/

	ang.controller("CustomerMenuController", function($rootScope,$scope){
		$scope.searchText = "";
		$scope.updateView = function() {
			$rootScope.$broadcast("filter_change",$scope.searchText);
		}
	});

	/*
		Create a CustomerListController function and 
		inject $scope to it.
	*/
	ang.controller("CustomerListController", function($scope,CustomerService){

		$scope.customers = []; // Model data
		
		CustomerService.getCustomers().then(function(data){
			$scope.customers = data.data;
			customersData = data.data;
		});

		$scope.delete = function(customer) {
			// call service to delete the customer from backend
			CustomerService.deleteCustomer(customer.id).then(function(data){
				$scope.customers.splice($scope.customers.indexOf(customer),1);
			});
			
		}

		$scope.$on("filter_change", function(evt,txt){
			var result = [];
			customersData.forEach(function(customer) {
				if(customer.firstName.toUpperCase().indexOf(txt.toUpperCase()) >=0
					|| customer.lastName.indexOf(txt) >=0) {
					result.push(customer);
				}
			});  
			$scope.customers = result;
		});
	});
})();