/**
* Customer controller
*/

(function(){
	// declare a CustomerModule with NO DI [ Dependency Injection ]
	var ang = angular.module("CustomerModule",['CustomerDirectiveModule']);

	/*
		Create a CustomerMenuController function and inject $scope and $rootScope
	*/

	ang.controller("CustomerMenuController", function($rootScope,$scope){
		$scope.searchText = "";
		$scope.updateView = function() {
			$rootScope.$broadcast("filter_change",$scope.searchText);
		}
	});

	/*
		Create a CustomerListController function and 
		inject $scope to it.
	*/
	ang.controller("CustomerListController", function($scope){

		$scope.viewType = "LIST";

		$scope.customers = customersData; // Model data
		
		$scope.delete = function(customer) {
			// call service to delete the customer from backend
			$scope.customers.splice($scope.customers.indexOf(customer),1);
		}

		$scope.$on("filter_change", function(evt,txt){
			var result = [];
			customersData.forEach(function(customer) {
				if(customer.firstName.toUpperCase().indexOf(txt.toUpperCase()) >=0
					|| customer.lastName.indexOf(txt) >=0) {
					result.push(customer);
				}
			});  
			$scope.customers = result;
		});
	});

	var customersData = [
		{"id":100,"firstName":"Rajesh","lastName":"Kumar","gender":"male","address":"Some address"},
		{"id":101,"firstName":"Kiran","lastName":"Kumar","gender":"male","address":"Some address"},
		{"id":102,"firstName":"Sunitha","lastName":"Kumari","gender":"female","address":"Some address"},
		{"id":103,"firstName":"Larry","lastName":"Page","gender":"male","address":"Some address"},
		{"id":104,"firstName":"Kavya","lastName":"Rao","gender":"female","address":"Some address"},
		{"id":105,"firstName":"Prasad","lastName":"Rao","gender":"male","address":"Some address"}
	];
})();