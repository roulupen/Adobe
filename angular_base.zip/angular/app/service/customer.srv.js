/*
	Customer Service  Module
*/

(function(){
	var ang = angular.module("CustomerServiceModule",[]);

	// inject http and promise service
	ang.service("CustomerService",function($http,$q){
		this.getCustomers = function() {
			var defered = $q.defer();
			$http({
  				method: 'GET',
 				 url: 'http://localhost:9000/customers'
			}).then(function(response) {
    			/* success code */
    			defered.resolve(response);
 			 }, function(response) {
     			defered.reject(response)
  			});
  			return defered.promise;
		};

		this.deleteCustomer = function(id) {
			var defered = $q.defer();
			$http({
  				method: 'DELETE',
 				 url: 'http://localhost:9000/customers/' + id
			}).then(function(response) {
    			/* success code */
    			defered.resolve(response);
 			 }, function(response) {
     			defered.reject(response)
  			});
  			return defered.promise;
		};
	});
})();