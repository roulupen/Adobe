/*
* Directives used for Customer Model
*/

(function(){
	var ang = angular.module("CustomerDirectiveModule",[]);
	ang.directive("cardView", function(){
		return {
			'restrict': 'EA',
			'templateUrl' : 'app/partials/card.tmpl.html'

		}
	});

	ang.directive("listView", function(){
		return {
			'restrict': 'EA',
			'templateUrl' : 'app/partials/list.tmpl.html'
		}
	});
})();